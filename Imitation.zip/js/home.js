	$(document).hover(function(){
	    $('[data-toggle="popover"]').popover();   
	});
	
	