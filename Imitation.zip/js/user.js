window.onload=function(){
	
	$(".us_box").hide();
	$("us_box_").click(function(){
		$(".us_box").hide();
		let index = $(this).Attr("index");
		$(".us_box" + index).show();
	})
	
	
	var day_=new Date();
	var sun_=new Date();
	var year_=new Date();
	var data_=["星期天","星期一","星期二","星期三","星期四","星期五","星期六"];
	document.getElementById("day").innerHTML=day_.getDate();
	document.getElementById("sun").innerHTML=data_[sun_.getDay()];
	document.getElementById("year").innerHTML=""+year_.getFullYear()+"."+(year_.getMonth()+1);
	
	var img_=document.getElementById("us_img");
	img_.onmouseover=function(){this.src="../images/img_7-2.png"};
	img_.onmouseout=function(){this.src="../images/img_7-1.png"};
	
}