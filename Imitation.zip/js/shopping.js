$(function(){
	$(".num_").click(function(){
		$input = $(this).next('input');
		$input.attr('value')*1;
		if(($input.attr('value'))*1>0)
			$input.attr('value',($input.attr('value'))*1-1);
	});
	$(".num_add").click(function(){
		$input = $(this).prev('input');
		$input.attr('value',($input.attr('value'))*1+1);
	});
})